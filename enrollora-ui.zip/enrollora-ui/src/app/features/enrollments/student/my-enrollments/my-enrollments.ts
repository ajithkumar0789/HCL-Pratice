import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { CancellationService } from '../../../cancellation/cancellation.service';
import { CreateCancellationRequest } from '../../../cancellation/cancellation.models';
import { EnrollmentResponse } from '../../enrollment.models';
import { EnrollmentService } from '../../enrollment.service';

@Component({
  selector: 'app-my-enrollments',
  standalone: true,
  imports: [CommonModule, FormsModule],
  styleUrl: './my-enrollments.css',
  templateUrl: './my-enrollments.html',
})
export class MyEnrollments implements OnInit {
  private readonly enrollmentService = inject(EnrollmentService);
  private readonly cancellationService = inject(CancellationService);

  enrollments = signal<EnrollmentResponse[]>([]);
  isLoading = signal(false);
  errorMessage = signal('');

  // Cancel modal
  showCancelModal = signal(false);
  cancelEnrollment = signal<EnrollmentResponse | null>(null);
  cancelReason = '';
  isCancelling = signal(false);
  cancelError = signal('');
  cancelSuccess = signal('');
  pageNumber = signal(1);
  pageSize = signal(10);
  totalRecords = signal(0);
  totalPages = signal(0);

  ngOnInit(): void {
    this.loadEnrollments();
  }

  loadEnrollments(): void {
    this.isLoading.set(true);
    this.errorMessage.set('');

    this.enrollmentService
      .getMyEnrollments(this.pageNumber(), this.pageSize())
      .subscribe({
        next: (response) => {
          this.enrollments.set(response.items);
          this.totalRecords.set(response.totalRecords);
          this.totalPages.set(response.totalPages);
          this.isLoading.set(false);
        },
        error: (error: HttpErrorResponse) => {
          const body = error.error;
          this.errorMessage.set(
            body?.detail || body?.message || body?.title ||
            'Unable to load your enrollments.',
          );
          this.isLoading.set(false);
        },
      });
  }

  statusLabel(status: number): string {
    return status === 1 ? 'Active' : 'Cancelled';
  }

  openCancelModal(enrollment: EnrollmentResponse): void {
    this.cancelEnrollment.set(enrollment);
    this.cancelReason = '';
    this.cancelError.set('');
    this.cancelSuccess.set('');
    this.showCancelModal.set(true);
  }

  closeCancelModal(): void {
    this.showCancelModal.set(false);
    this.cancelEnrollment.set(null);
  }

  submitCancellation(): void {
    if (!this.cancelReason.trim()) {
      this.cancelError.set('Please provide a reason for cancellation.');
      return;
    }

    const enrollment = this.cancelEnrollment();
    if (!enrollment) return;

    this.isCancelling.set(true);
    this.cancelError.set('');

    const request: CreateCancellationRequest = { reason: this.cancelReason.trim() };

    this.cancellationService.create(enrollment.enrollmentId, request).subscribe({
      next: () => {
        this.isCancelling.set(false);
        this.cancelSuccess.set('Cancellation request submitted successfully!');
        setTimeout(() => this.closeCancelModal(), 1800);
      },
      error: (err: HttpErrorResponse) => {
        const body = err.error;
        this.cancelError.set(
          body?.detail || body?.message || body?.title ||
          'Failed to submit cancellation request.',
        );
        this.isCancelling.set(false);
      },
    });
  }

  previousPage(): void {
    if (this.pageNumber() > 1) {
      this.pageNumber.update((page) => page - 1);
      this.loadEnrollments();
    }
  }

  nextPage(): void {
    if (this.pageNumber() < this.totalPages()) {
      this.pageNumber.update((page) => page + 1);
      this.loadEnrollments();
    }
  }
}
