import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { CancellationResponse, CancellationStatus } from '../../cancellation.models';
import { CancellationService } from '../../cancellation.service';

@Component({
  selector: 'app-my-cancellation-requests',
  standalone: true,
  imports: [CommonModule, FormsModule, DatePipe],
  styleUrl: './my-cancellation-requests.css',
  templateUrl: './my-cancellation-requests.html',
})
export class MyCancellationRequests implements OnInit {
  private readonly cancellationService = inject(CancellationService);

  requests = signal<CancellationResponse[]>([]);
  isLoading = signal(false);
  errorMessage = signal('');
  pageNumber = signal(1);
  pageSize = signal(10);
  totalRecords = signal(0);
  totalPages = signal(0);

  readonly CancellationStatus = CancellationStatus;

  ngOnInit(): void {
    this.loadRequests();
  }

  loadRequests(): void {
    this.isLoading.set(true);
    this.errorMessage.set('');

    this.cancellationService
      .getMine(this.pageNumber(), this.pageSize())
      .subscribe({
        next: (res) => {
          this.requests.set(res.items);
          this.totalRecords.set(res.totalRecords);
          this.totalPages.set(res.totalPages);
          this.isLoading.set(false);
        },
        error: (err: HttpErrorResponse) => {
          const body = err.error;
          this.errorMessage.set(
            body?.detail || body?.message || body?.title ||
            'Unable to load cancellation requests.',
          );
          this.isLoading.set(false);
        },
      });
  }

  statusLabel(status: CancellationStatus): string {
    switch (status) {
      case CancellationStatus.Pending: return 'Pending';
      case CancellationStatus.Approved: return 'Approved';
      case CancellationStatus.Rejected: return 'Rejected';
    }
  }

  statusClass(status: CancellationStatus): string {
    switch (status) {
      case CancellationStatus.Pending: return 'pending';
      case CancellationStatus.Approved: return 'approved';
      case CancellationStatus.Rejected: return 'rejected';
    }
  }

  previousPage(): void {
    if (this.pageNumber() > 1) {
      this.pageNumber.update((p) => p - 1);
      this.loadRequests();
    }
  }

  nextPage(): void {
    if (this.pageNumber() < this.totalPages()) {
      this.pageNumber.update((p) => p + 1);
      this.loadRequests();
    }
  }
}
