import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { PagedResult } from '../../shared/models/paged-result.model';
import {
  CancellationFilter,
  CancellationResponse,
  CreateCancellationRequest,
  ReviewCancellationRequest,
} from './cancellation.models';

@Injectable({ providedIn: 'root' })
export class CancellationService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = `${environment.apiUrl}`;

  /** Admin: get all cancellation requests */
  getAll(
    pageNumber = 1,
    pageSize = 10,
    filters?: CancellationFilter,
  ): Observable<PagedResult<CancellationResponse>> {
    return this.http.get<PagedResult<CancellationResponse>>(
      `${this.baseUrl}/cancellation-requests`,
      { params: this.buildParams(pageNumber, pageSize, filters) },
    );
  }

  /** Student: get own cancellation requests */
  getMine(
    pageNumber = 1,
    pageSize = 10,
  ): Observable<PagedResult<CancellationResponse>> {
    return this.http.get<PagedResult<CancellationResponse>>(
      `${this.baseUrl}/cancellation-requests/my`,
      { params: new HttpParams().set('pageNumber', pageNumber).set('pageSize', pageSize) },
    );
  }

  /** Student: request cancellation for an enrollment */
  create(
    enrollmentId: number,
    request: CreateCancellationRequest,
  ): Observable<CancellationResponse> {
    return this.http.post<CancellationResponse>(
      `${this.baseUrl}/enrollments/${enrollmentId}/cancellation-request`,
      request,
    );
  }

  /** Admin: approve a request */
  approve(
    requestId: number,
    body: ReviewCancellationRequest,
  ): Observable<CancellationResponse> {
    return this.http.put<CancellationResponse>(
      `${this.baseUrl}/cancellation-requests/${requestId}/approve`,
      body,
    );
  }

  /** Admin: reject a request */
  reject(
    requestId: number,
    body: ReviewCancellationRequest,
  ): Observable<CancellationResponse> {
    return this.http.put<CancellationResponse>(
      `${this.baseUrl}/cancellation-requests/${requestId}/reject`,
      body,
    );
  }

  private buildParams(
    pageNumber: number,
    pageSize: number,
    filters?: CancellationFilter,
  ): HttpParams {
    let params = new HttpParams()
      .set('pageNumber', pageNumber)
      .set('pageSize', pageSize);

    if (filters?.search) params = params.set('search', filters.search);
    if (filters?.courseId != null) params = params.set('courseId', filters.courseId);
    if (filters?.status != null) params = params.set('status', filters.status);
    if (filters?.fromDate) params = params.set('fromDate', filters.fromDate);
    if (filters?.toDate) params = params.set('toDate', filters.toDate);

    return params;
  }
}
