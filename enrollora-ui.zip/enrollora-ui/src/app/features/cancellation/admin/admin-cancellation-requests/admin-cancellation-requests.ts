import { CommonModule, DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { CancellationResponse, CancellationStatus, ReviewCancellationRequest } from '../../cancellation.models';
import { CancellationService } from '../../cancellation.service';

@Component({
  selector: 'app-admin-cancellation-requests',
  standalone: true,
  imports: [CommonModule, FormsModule, DatePipe],
  styleUrl: './admin-cancellation-requests.css',
  templateUrl: './admin-cancellation-requests.html',
})
export class AdminCancellationRequests implements OnInit {
  private readonly cancellationService = inject(CancellationService);

  requests = signal<CancellationResponse[]>([]);
  isLoading = signal(false);
  errorMessage = signal('');
  pageNumber = signal(1);
  pageSize = signal(10);
  totalRecords = signal(0);
  totalPages = signal(0);

  // filter
  searchTerm = '';
  statusFilter: string = '';

  // review modal
  showModal = signal(false);
  modalAction = signal<'approve' | 'reject'>('approve');
  selectedRequest = signal<CancellationResponse | null>(null);
  adminRemarks = '';
  isSubmitting = signal(false);
  modalError = signal('');

  readonly CancellationStatus = CancellationStatus;

  ngOnInit(): void {
    this.loadRequests();
  }

  loadRequests(): void {
    this.isLoading.set(true);
    this.errorMessage.set('');

    const filters = {
      search: this.searchTerm || undefined,
      status: this.statusFilter !== '' ? Number(this.statusFilter) as CancellationStatus : undefined,
    };

    this.cancellationService.getAll(this.pageNumber(), this.pageSize(), filters).subscribe({
      next: (res) => {
        this.requests.set(res.items);
        this.totalRecords.set(res.totalRecords);
        this.totalPages.set(res.totalPages);
        this.isLoading.set(false);
      },
      error: (err: HttpErrorResponse) => {
        const body = err.error;
        this.errorMessage.set(
          body?.detail || body?.message || body?.title ||
          'Unable to load cancellation requests.',
        );
        this.isLoading.set(false);
      },
    });
  }

  applyFilter(): void {
    this.pageNumber.set(1);
    this.loadRequests();
  }

  openReview(request: CancellationResponse, action: 'approve' | 'reject'): void {
    this.selectedRequest.set(request);
    this.modalAction.set(action);
    this.adminRemarks = '';
    this.modalError.set('');
    this.showModal.set(true);
  }

  closeModal(): void {
    this.showModal.set(false);
    this.selectedRequest.set(null);
  }

  submitReview(): void {
    const req = this.selectedRequest();
    if (!req) return;

    this.isSubmitting.set(true);
    this.modalError.set('');

    const body: ReviewCancellationRequest = { adminRemarks: this.adminRemarks || undefined };
    const obs$ = this.modalAction() === 'approve'
      ? this.cancellationService.approve(req.cancellationRequestId, body)
      : this.cancellationService.reject(req.cancellationRequestId, body);

    obs$.subscribe({
      next: (updated) => {
        this.requests.update((list) =>
          list.map((r) => r.cancellationRequestId === updated.cancellationRequestId ? updated : r),
        );
        this.isSubmitting.set(false);
        this.closeModal();
      },
      error: (err: HttpErrorResponse) => {
        const body = err.error;
        this.modalError.set(
          body?.detail || body?.message || body?.title || 'Action failed. Please try again.',
        );
        this.isSubmitting.set(false);
      },
    });
  }

  statusLabel(status: CancellationStatus): string {
    switch (status) {
      case CancellationStatus.Pending:  return 'Pending';
      case CancellationStatus.Approved: return 'Approved';
      case CancellationStatus.Rejected: return 'Rejected';
    }
  }

  statusClass(status: CancellationStatus): string {
    switch (status) {
      case CancellationStatus.Pending:  return 'pending';
      case CancellationStatus.Approved: return 'approved';
      case CancellationStatus.Rejected: return 'rejected';
    }
  }

  previousPage(): void {
    if (this.pageNumber() > 1) {
      this.pageNumber.update((p) => p - 1);
      this.loadRequests();
    }
  }

  nextPage(): void {
    if (this.pageNumber() < this.totalPages()) {
      this.pageNumber.update((p) => p + 1);
      this.loadRequests();
    }
  }
}
