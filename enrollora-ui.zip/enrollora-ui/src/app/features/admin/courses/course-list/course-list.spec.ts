import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CourseListComponent } from './course-list';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

describe('CourseListComponent', () => {
  let component: CourseListComponent;
  let fixture: ComponentFixture<CourseListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CourseListComponent],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(CourseListComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open the add modal when openAddModal() is called', () => {
    component.openAddModal();
    expect(component.showFormModal()).toBeTrue();
    expect(component.modalMode()).toBe('add');
  });

  it('should validate empty course name', () => {
    component.openAddModal();
    component.form.courseName = '';
    component.submitForm();
    expect(component.formError()).toBe('Course name is required.');
    expect(component.isSubmitting()).toBeFalse();
  });

  it('should validate fees as a valid number', () => {
    component.openAddModal();
    component.form.courseName = 'Test';
    component.form.duration = '3 months';
    // Simulate cleared field → empty string coerced
    (component.form as any).fees = '';
    component.submitForm();
    expect(component.formError()).toContain('Fees');
  });

  it('should validate capacity >= 1', () => {
    component.openAddModal();
    component.form.courseName = 'Test';
    component.form.duration = '3 months';
    component.form.fees = 100;
    component.form.capacity = 0;
    component.submitForm();
    expect(component.formError()).toBe('Capacity must be at least 1.');
  });
});
